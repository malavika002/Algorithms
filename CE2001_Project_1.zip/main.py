"""
CE2001 - Algorithms
Group Project 1 - 'Searching Algorithm'
Lab SE2
Group Members -
1. Kesarimangalam Srinivasan Abhinaya
2. Musthiri Sajna
3. Singh Aishwarya
4. Unnikrishnan Malavika

Algorithms are ordered on the basis of decreasing time complexity -
1. bruteForce
2. firstLast
3. slicing
"""

import os
import time

search = "TTTATACCTTCC"
n = len(search) # length of search element


def bruteForce(search, sequence):
    positions = [] # list of starting indices of matching genomes
    for i in range(len(sequence)):
        flag = 1 # checkpoint for confirming if search element not found in ith iteration
        for j in range(n): # n is global variable storing length of search element
            if search[j] != sequence[i + j]:
                flag = 0 # checkpoint for confirming if search element not found in ith iteration
                break
            else:
                continue
        if flag:
            #print(positions)
            positions.append(i)
    if len(positions) == 0:
        print("No occurrence")
    else:
        print(positions)


def slicing(search, sequence):
    positions = []
    for i in range(len(sequence)):
        if sequence[i:n + i] == search:
            #print(positions)
            positions.append(i)
    if len(positions) == 0:
        print("No occurrence")
    else:
        print(positions)


def firstLast(search, sequence):
    positions = []
    seq = []
    for i in range(len(sequence)):
        if sequence[i: i + 4] == search[0:4] and sequence[i + n - 4: i + n] == search[n - 4:n]:
            #print(positions)
            positions.append(i)
            seq.append(sequence[i:i + n])
    final_pos = []
    for j in range(len(seq)):
        if seq[j] == search:
            final_pos.append(positions[j])
            continue
    if len(final_pos) == 0:
        print("No occurrence")
    else:
        print(final_pos)


choice = int(input("Please choose 1 for bruteForce, 2 for firstLast and 3 for slicing: \n"))
directory = r'C:\Users\Aishwarya Singh\PycharmProjects\CE2001_P1\data'
count = 0
for filename in os.listdir(directory):
    f = open("data\\" + filename, "r")
    sequence = f.read()
    if choice == 1:
        start_time = time.time()
        bruteForce(search, sequence)
        print("--- %s seconds ---" % (time.time() - start_time))
    elif choice == 2:
        start_time = time.time()
        firstLast(search, sequence)
        print("--- %s seconds ---" % (time.time() - start_time))
    elif choice == 3:
        start_time = time.time()
        slicing(search, sequence)
        print("--- %s seconds ---" % (time.time() - start_time))
    else:
        print("Incorrect choice! Restart program to pick again!")
    f.close()

